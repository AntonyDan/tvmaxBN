var navCtrl = app.controller('navCtrl', function($scope, $route) {
	'use strict';

	$scope.$route = $route;
});
